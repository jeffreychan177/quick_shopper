launch index.js using:
    node index.js
launch index.html as live server using vs code plugin